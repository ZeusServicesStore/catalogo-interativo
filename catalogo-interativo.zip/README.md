# Catálogo Interativo de Produtos

Este projeto é um catálogo interativo em React + Tailwind.

## Instruções
1. `npm install`
2. `npm run dev`

Ideal para publicar no Vercel.